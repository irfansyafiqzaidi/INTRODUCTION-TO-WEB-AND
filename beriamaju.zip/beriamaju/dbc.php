<?php

$hostname="localhost";
$userid="root";
$userpass="";
$dbname="burgerorderingdb";
//$port = "3302";

$dbc = mysqli_connect($hostname,$userid,$userpass,$dbname);

if (!$dbc) 
{
    die("Database connection failed: " . mysqli_connect_error());
}
?>