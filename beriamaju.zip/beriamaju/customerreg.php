<?php
session_start();
include "dbc.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cic = $_POST['cic'];
    $cname = $_POST['cname'];
    $cphone = $_POST['cphone'];

    // SQL query to insert data into the customers table
    $sql = "INSERT INTO customer (customer_ic, customer_name, customer_phonenum) VALUES ('$cic', '$cname', '$cphone')";

    if ($dbc->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $dbc->error;
    }

    $dbc->close();
}
?>