<?php
session_start();
if (isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Beria Maju Enterprise</title>
	<link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<section class="header">
	<nav>
		<a href="index.php"><img src="images/logo.jpg"></a>
		<div class="nav-links">
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php">ABOUT</a></li>
				<li><a href="displaymenu.php">MENU</a></li>
				<li><a href="loginPage.php">STAFF PAGE</a></li>
			</ul>
	</nav>

<div class="text-box">
	<h1>Beria Maju Enterprise Burger</h1>
	<p>To serve the best food, always.</p>
	<a href="cust_login.php" class="hero-btn">START ORDER</a>
	
</div>

	</section>

<!-----footer-------->

<section class="footer">
	<h4>About us</h4>
	<p>Beria Maju Enterprise Burger is a restaurant that specializes in supplying the finest western food especially burgers.</p>
</section>

</body>
</html>