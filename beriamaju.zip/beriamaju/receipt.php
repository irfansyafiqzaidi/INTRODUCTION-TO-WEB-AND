<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $cardnumber = $_POST['cardnumber'];
    $expiry = $_POST['expiry'];
    $cvv = $_POST['cvv'];

    // In real-world applications, payment processing will be done here

    $order_id = rand(1000, 9999); // Example order ID
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beria Maju Enterprise - Receipt</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<section class="sub-header3">
    <nav>
        <a href="index.php"><img src="images/logo.jpg"></a>
        <div class="nav-links">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="displaymenu.php">MENU</a></li>
            </ul>
        </div>
    </nav>

</section>


<section class="receipt-display">
    <div class="container">
        <h2>Receipt</h2>
        <p>Thank you for your purchase, <?php echo $name; ?>.</p>
        <p>Your order ID is: <?php echo $order_id; ?></p>
        <h3>Order Details:</h3>
        <div class="cart-items">
            <?php
            if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
                $total = 0;
                foreach ($_SESSION['cart'] as $item) {
                    echo "<div class='cart-item'>";
                    echo "<h3>" . $item['name'] . "</h3>";
                    echo "<p>Price: $" . number_format($item['price'], 2) . "</p>";
                    echo "<p>Quantity: " . $item['qty'] . "</p>";
                    $total += $item['price'] * $item['qty'];
                    echo "</div>";
                }
                echo "<h3>Total: $" . number_format($total, 2) . "</h3>";
                unset($_SESSION['cart']); // Clear the cart
            } else {
                echo "<p>No order details found.</p>";
            }
            ?>
        </div>
    </div>
</section>
</body>
</html>