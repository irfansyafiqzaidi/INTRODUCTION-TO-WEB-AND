<?php
session_start();
include('dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $custIc = $_POST['cust_ic'];
    $cpassword = $_POST['cust_password'];

    $query = "SELECT * FROM customer WHERE customer_ic = '$custIc' AND customer_password = '$cpassword'";
    $result = $dbc->query($query);

    if ($result->num_rows > 0) {
        // Successful login
        $row = $result->fetch_assoc();
        $_SESSION['customer_ic'] = $row['customer_ic'];
        $_SESSION['customer_name'] = $row['customer_name'];
        header("Location: menu.php");
        exit();
    } else {
        // Invalid login
        header("Location: cust_login.php?error=invalid");
        exit();
    }
} else {
    // Redirect to login page if the request method is not POST
    header("Location: cust_login.php");
    exit();
}
?>