<?php
session_start();

// Clear cart session
unset($_SESSION['cart']);
$_SESSION['cart'] = array();

// Redirect back to menu page or any other appropriate page
header("Location: menu.php");
exit();
?>
