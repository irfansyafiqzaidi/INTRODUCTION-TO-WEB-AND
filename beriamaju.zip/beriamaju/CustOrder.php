<?php
session_start();
include('dbconnect.php');

// Delete order if delete button is clicked
if (isset($_POST['delete'])) {
    $order_id = $_POST['order_id'];
    $delete_sql = "DELETE FROM orders WHERE order_id = ?";
    $stmt = $dbc->prepare($delete_sql);
    $stmt->bind_param("s", $order_id);
    $stmt->execute();
    $stmt->close();
}

// Fetch orders from the database
$sql = "SELECT o.order_id, c.customer_ic, f.food_id, of.food_quantity 
        FROM orders o 
        JOIN customer c ON o.customer_ic = c.customer_ic 
        JOIN orders_food of ON o.order_id = of.order_id 
        JOIN food f ON of.food_id = f.food_id";
$result = $dbc->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Order</title>
    <link rel="stylesheet" href="CustOrderStyle.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
            </ul>
        </nav>
        <div class="dropdown">
            <button class="dropbtn"><i class="fas fa-bars"></i></button>
            <div class="dropdown-content">
                <a href="report.php">Report</a>
                <a href="SchedulePage.php">Schedule</a>
                <a href="#">Order</a>
                <a href="logout.php">Log out</a>
            </div>
        </div>
    </header>

    <main>
        <h1>Customer Order</h1>
        <div class="order-container">
            <table>
                <tr>
                    <th>Order ID</th>
                    <th>Customer IC</th>
                    <th>Food ID</th>
                    <th>Order Quantity</th>
                    <th>Action</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row["order_id"] . '</td>';
                        echo '<td>' . $row["customer_ic"] . '</td>';
                        echo '<td>' . $row["food_id"] . '</td>';
                        echo '<td>' . $row["food_quantity"] . '</td>';
                        echo '<td>
                                <form method="post" action="">
                                    <input type="hidden" name="order_id" value="' . $row["order_id"] . '">
                                    <button type="submit" name="delete" class="delete-button">Delete</button>
                                </form>
                              </td>';
                        echo '</tr>';
                    }
                } else {
                    echo "<tr><td colspan='5'>No results found</td></tr>";
                }
                $dbc->close();
                ?>
            </table>
        </div>
    </main>

</body>
</html>
