<?php
session_start();
include('dbc.php');

// Retrieve customer_ic from session
$customer_ic = $_SESSION['customer_ic'];

// Fetch cart items for the customer
$sql = "SELECT cart.cart_id, food.food_name, food.food_price, cart.quantity 
        FROM cart 
        JOIN food ON cart.food_id = food.food_id 
        WHERE cart.customer_ic = ?";
$stmt = $dbc->prepare($sql);
$stmt->bind_param('s', $customer_ic);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
while ($row = $result->fetch_assoc()) {
    $cart_items[] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beria Maju Enterprise - Cart</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
<section class="cart-display">
    <div class="container">
        <h2>Your Cart</h2>
        <div class="cart-items">
            <?php if (count($cart_items) > 0): ?>
                <?php 
                $total = 0;
                foreach ($cart_items as $item): 
                    $total += $item['food_price'] * $item['quantity'];
                ?>
                    <div class="cart-item">
                        <h3><?php echo htmlspecialchars($item['food_name']); ?></h3>
                        <p>Price: $<?php echo number_format($item['food_price'], 2); ?></p>
                        <p>Quantity: <?php echo htmlspecialchars($item['quantity']); ?></p>
                    </div>
                <?php endforeach; ?>
                <h3>Total: $<?php echo number_format($total, 2); ?></h3>
                <a href="payment2.php" class="button">Proceed to Payment</a>
            <?php else: ?>
                <p>Your cart is empty.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
</body>
</html>
