<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Schedule</title>
    <link rel="stylesheet" href="SchedulePageStyle.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>   
            </ul>
        </nav>
        <div class="dropdown">
            <button class="dropbtn"><i class="fas fa-bars"></i></button>
            <div class="dropdown-content">
                <a href="report.php">Report</a>
                <a href="#">Schedule</a>
                <a href="CustOrder.php">Order</a>
                <a href="logout.php">Log out</a>
            </div>
        </div>
    </header>

    <main>
        <h1>Schedule</h1>
        <div class="menu-container" id="schedule-container">
            <?php
                session_start();
                include('dbconnect.php');

                if (!isset($_SESSION['staff_id']) || !isset($_SESSION['staff_name'])) {
                    header("Location: loginPage.php");
                    exit();
                }

                // Display success message if schedule was updated
                if (isset($_GET['status']) && $_GET['status'] === 'success') {
                    echo "<p style='color: green;'>Schedule updated successfully!</p>";
                }

                // Fetch staff details from session
                $staffId = $_SESSION['staff_id'];
                $staffName = $_SESSION['staff_name'];
            ?>
            <div class="staff-info">
                <p>Staff ID: <?php echo $staffId; ?></p>
                <p>Staff Name: <?php echo $staffName; ?></p>
            </div>
            <div class="schedule-table-container">
                <?php
                    if ($dbc) {
                        echo "<table id='schedule-table'>";
                        echo "<thead>";
                        echo "<tr>";
                        echo "<th>DAY</th>";
                        echo "<th>START SHIFT</th>";
                        echo "<th>END SHIFT</th>";
                        echo "</tr>";
                        echo "</thead>";
                        echo "<tbody id='schedule-body'>";

                        $daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                        $query = "SELECT day, start_time, end_time 
                                  FROM shift 
                                  WHERE staff_id = '$staffId'
                                  ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday')";
                        $result = $dbc->query($query);

                        $fetchedDays = [];
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                $fetchedDays[] = $row['day'];
                                echo "<tr>";
                                echo "<td>" . $row['day'] . "</td>";
                                echo "<td>" . $row['start_time'] . "</td>";
                                echo "<td>" . $row['end_time'] . "</td>";
                                echo "</tr>";
                            }
                        }

                        // Fill in missing days with default values
                        foreach ($daysOfWeek as $day) {
                            if (!in_array($day, $fetchedDays)) {
                                echo "<tr>";
                                echo "<td>$day</td>";
                                echo "<td>--:--:--</td>";
                                echo "<td>--:--:--</td>";
                                echo "</tr>";
                            }
                        }

                        echo "</tbody>";
                        echo "</table>";
                    } else {
                        echo "Database connection failed.";
                    }
                ?>
                <div id="edit-button-container">
                    <button id="edit-button">Edit Schedule</button>
                </div>
            </div>
        </div>

        <div class="menu-container" id="form-container" style="display:none;">
            <h1>Edit Schedule</h1>
            <div class="staff-info">
                <p>Staff ID: <?php echo $staffId; ?></p>
                <p>Staff Name: <?php echo $staffName; ?></p>
            </div>
            <form name="frmstaff" id="staff-form" action="handle_schedule_update.php" method="post">
                <input type="hidden" name="staffid" value="<?php echo $staffId; ?>">
                <table>
                    <thead>
                        <tr>
                            <th>DAY</th>
                            <th>START SHIFT</th>
                            <th>END SHIFT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <select name="fstaffday" id="staff-day" required>
                                    <option value="Monday">Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                </select>
                            </td>
                            <td><input type="time" name="fstaffstarttime" id="staff-starttime" required></td>
                            <td><input type="time" name="fstaffendtime" id="staff-endtime" required></td>
                        </tr>
                    </tbody>
                </table>
                <div style="text-align: center; margin-top: 1rem;">
                    <input type="submit" value="Update Schedule" style="background-color: #FFC107; color: black; padding: 0.75rem; border: none; cursor: pointer; border-radius: 5px;">
                    <button type="button" id="back-button" style="background-color: #FFC107; color: black; padding: 0.75rem; border: none; cursor: pointer; border-radius: 5px;">Back</button>
                </div>
            </form>
        </div>
    </main>

    <script>
        document.getElementById('edit-button').addEventListener('click', function() {
            document.getElementById('schedule-container').style.display = 'none';
            document.getElementById('form-container').style.display = 'block';
        });

        document.getElementById('back-button').addEventListener('click', function() {
            document.getElementById('form-container').style.display = 'none';
            document.getElementById('schedule-container').style.display = 'block';
        });

        document.getElementById('staff-form').addEventListener('submit', function(e) {
            e.preventDefault();
            var form = document.getElementById('staff-form');
            var formData = new FormData(form);

            fetch('handle_schedule_update.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                // Reload the page to show the updated schedule
                window.location.href = "SchedulePage.php?status=success";
            })
            .catch(error => console.error('Error:', error));
        });
    </script>
</body>
</html>
