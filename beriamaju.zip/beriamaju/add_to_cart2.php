<?php
session_start();
require 'dbc.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $food_id = $_POST['food_id'];
    $quantity = $_POST['quantity'];
    $customer_ic = $_SESSION['customer_ic']; // Assuming customer is logged in

    // Check if cart already has the item
    $query = "SELECT * FROM cart WHERE food_id=? AND customer_ic=?";
    $stmt = $dbc->prepare($query);
    $stmt->bind_param("ss", $food_id, $customer_ic);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update quantity if item exists in cart
        $query = "UPDATE cart SET quantity=quantity+? WHERE food_id=? AND customer_ic=?";
        $stmt = $dbc->prepare($query);
        $stmt->bind_param("iss", $quantity, $food_id, $customer_ic);
    } else {
        // Add new item to cart
        $query = "INSERT INTO cart (cart_id, customer_ic, food_id, quantity) VALUES (UUID(), ?, ?, ?)";
        $stmt = $dbc->prepare($query);
        $stmt->bind_param("ssi", $customer_ic, $food_id, $quantity);
    }
    $stmt->execute();

    header("Location: cart2.php");
    exit();
}
?>
