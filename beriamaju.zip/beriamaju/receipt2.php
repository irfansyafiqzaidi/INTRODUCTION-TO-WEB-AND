<?php
session_start();
include('dbc.php');

// Assuming order_id is passed via GET parameter
$order_id = isset($_GET['order_id']) ? trim($_GET['order_id']) : '';

if (!$order_id) {
    die("Order ID is required.");
}

// Fetch order details
$sql_order = "SELECT * FROM orders WHERE order_id = ?";
$stmt_order = $dbc->prepare($sql_order);
if (!$stmt_order) {
    die("Prepare failed: (" . $dbc->errno . ") " . $dbc->error);
}
$stmt_order->bind_param('s', $order_id);
$stmt_order->execute();
$result_order = $stmt_order->get_result();
$order = $result_order->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

// Fetch customer details
$customer_ic = $order['customer_ic'];
$sql_customer = "SELECT * FROM customer WHERE customer_ic = ?";
$stmt_customer = $dbc->prepare($sql_customer);
$stmt_customer->bind_param('s', $customer_ic);
$stmt_customer->execute();
$result_customer = $stmt_customer->get_result();
$customer = $result_customer->fetch_assoc();

if (!$customer) {
    die("Customer not found.");
}

// Fetch order food details
$sql_order_food = "SELECT food.food_name, orders_food.food_quantity, food.food_price, 
                   (orders_food.food_quantity * food.food_price) as total_price 
                   FROM orders_food 
                   JOIN food ON orders_food.food_id = food.food_id 
                   WHERE orders_food.order_id = ?";
$stmt_order_food = $dbc->prepare($sql_order_food);
if (!$stmt_order_food) {
    die("Prepare failed: (" . $dbc->errno . ") " . $dbc->error);
}
$stmt_order_food->bind_param('s', $order_id);
$stmt_order_food->execute();
$result_order_food = $stmt_order_food->get_result();

if (!$result_order_food) {
    die("Execute failed: (" . $dbc->errno . ") " . $dbc->error);
}

$order_foods = [];
$total_payment = 0;

while ($row = $result_order_food->fetch_assoc()) {
    $order_foods[] = $row;
    $total_payment += $row['total_price'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 15px 0;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        .nav-links {
            display: flex;
            justify-content: center;
            list-style: none;
            padding: 0;
        }
        .nav-links li {
            margin: 0 10px;
        }
        .nav-links a {
            color: #fff;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .nav-links a:hover {
            background-color: #575757;
        }
        .receipt {
            background-color: #fff;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .total {
            text-align: right;
        }
    </style>
</head>
<body>

<section class="header">
    <div class="container">
        <h1>Invoice</h1>
        <ul class="nav-links">
            <li><a href="index.php">HOME</a></li>
            <li><a href="about.php">ABOUT</a></li>
            <li><a href="displaymenu.php">MENU</a></li>
        </ul>
    </div>
</section>

<section class="container">
    <div class="receipt">
        <h2>Invoice</h2>
        <p>Order ID: <?php echo htmlspecialchars($order_id); ?></p>

        <h3>Customer Details:</h3>
        <p>Name: <?php echo htmlspecialchars($customer['customer_name']); ?></p>
        <p>Phone: <?php echo htmlspecialchars($customer['customer_phonenum']); ?></p>

        <h3>Order Details:</h3>
        <table>
            <tr>
                <th>Food Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
            <?php if (!empty($order_foods)): ?>
                <?php foreach ($order_foods as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['food_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['food_quantity']); ?></td>
                        <td><?php echo number_format($item['food_price'], 2); ?></td>
                        <td><?php echo number_format($item['total_price'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3" class="total"><strong>Total Payment:</strong></td>
                    <td><strong>$<?php echo number_format($total_payment, 2); ?></strong></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="4">No items found in the order.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</section>

</body>
</html>
