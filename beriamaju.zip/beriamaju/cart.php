<?php
session_start();
include 'dbc.php'; // Ensure this file contains the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['item_id'], $_POST['item_name'], $_POST['item_price'], $_POST['item_qty'])) {
    $item_id = $_POST['item_id'];
    $item_name = $_POST['item_name'];
    $item_price = $_POST['item_price'];
    $item_qty = $_POST['item_qty'];

    $item = array(
        'id' => $item_id,
        'name' => $item_name,
        'price' => $item_price,
        'qty' => $item_qty
    );

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    array_push($_SESSION['cart'], $item);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Your Cart</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<section class="sub-header3">
    <nav>
        <a href="index.php"><img src="images/logo.jpg"></a>
        <div class="nav-links">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="displaymenu.php">MENU</a></li>
            </ul>
        </div>
    </nav>
</section>

<section class="cart-display">
    <div class="container">
        <h2>Your Cart</h2>
        <div class="cart-items">
            <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) : ?>
                <?php
                $total = 0;
                foreach ($_SESSION['cart'] as $index => $item) {
                    echo "<div class='cart-item'>";
                    echo "<h3>" . $item['name'] . "</h3>";
                    echo "<p>Price: $" . number_format($item['price'], 2) . "</p>";
                    echo "<p>Quantity: " . $item['qty'] . "</p>";
                    echo "<form action='delete_from_cart.php' method='post'>";
                    echo "<input type='hidden' name='item_index' value='$index'>";
                    echo "<input type='hidden' name='item_id' value='" . $item['id'] . "'>";
                    echo "<button type='submit'>Delete</button>";
                    echo "</form>";
                    $total += $item['price'] * $item['qty'];
                    echo "</div>";
                }
                ?>
                <h3>Total: $<?php echo number_format($total, 2); ?></h3>
                <a href="payment2.php" class="button">Proceed to Payment</a>
                <a href="menu.php" class="button">Add More</a>
            <?php else : ?>
                <p>Your cart is empty.</p>
                <a href="menu.php" class="button">Add Items</a>
            <?php endif; ?>
        </div>
    </div>
</section>
</body>
</html>
