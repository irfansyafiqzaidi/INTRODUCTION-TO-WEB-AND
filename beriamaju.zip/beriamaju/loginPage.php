<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login</title>
    <link rel="stylesheet" href="LoginPageStyle.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>   
            </ul>
        </nav>
    </header>
  
    <main>
        <div class="wrapper">
            <h1>Login</h1>
            <?php
            if (isset($_GET['error']) && $_GET['error'] == 'invalid') {
                echo "<p style='color: red;'>Invalid login credentials. Please try again.</p>";
            }
            ?>
            <form action="handle_login.php" method="post">
                <div class="input-box">
                    <input type="text" name="staff_id" placeholder="Staff ID" required>
                </div>
                <div class="input-box">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit" class="btn">Login</button>
                <div class="register-link">
                    <p>Don't have an account? <a href="registerPage.php">Register</a></p>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
