<?php
session_start();
require 'dbc.php';

$customer_ic = $_SESSION['customer_ic']; // Assuming customer is logged in

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['total_payment'])) {
    $total_payment = $_POST['total_payment'];

    // Function to generate a 5-character unique ID
    function generateUniqueId($prefix) {
        return $prefix . substr(bin2hex(random_bytes(3)), 0, 5);
    }

    // Create new order
    $order_id = generateUniqueId('ORD');
    $query = "INSERT INTO orders (order_id, customer_ic, order_payment) VALUES (?, ?, ?)";
    $stmt = $dbc->prepare($query);
    $stmt->bind_param("ssd", $order_id, $customer_ic, $total_payment);
    $stmt->execute();

    // Fetch cart items from session
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $item) {
            $order_food_id = generateUniqueId('OF');
            $food_id = $item['id'];
            $quantity = $item['qty'];

            $query = "INSERT INTO orders_food (order_food_id, order_id, food_id, food_quantity) VALUES (?, ?, ?, ?)";
            $stmt = $dbc->prepare($query);
            $stmt->bind_param("sssi", $order_food_id, $order_id, $food_id, $quantity);
            $stmt->execute();
        }

        // Clear the session cart after successfully inserting all items
        unset($_SESSION['cart']);
    }

    // Redirect to receipt page with the generated order_id
    header("Location: receipt2.php?order_id=" . urlencode($order_id));
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Order Confirmation</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<section class="sub-header3">
    <nav>
        <a href="index.php"><img src="images/logo.jpg"></a>
        <div class="nav-links">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="displaymenu.php">MENU</a></li>
            </ul>
        </div>
    </nav>
</section>

<section class="payment-display">
    <div class="container">
        <h2>Create Invoice</h2>
        <form action="payment2.php" method="post">
            <input type="hidden" name="total_payment" value="<?php echo htmlspecialchars($total_payment); ?>">
            <button type="submit">Proceed</button>
        </form>
        <form action="cancel_order.php" method="post">
            <button type="submit">Cancel Order</button>
        </form>
    </div>
</section>
</body>
</html>
