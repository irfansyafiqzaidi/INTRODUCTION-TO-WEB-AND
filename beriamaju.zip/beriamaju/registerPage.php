<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Registration</title>
    <link rel="stylesheet" href="LoginPageStyle.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
    </header>

    <main>
        <div class="wrapper">
            <h1>Register</h1>
            <?php
            if (isset($_GET['error']) && $_GET['error'] == 'exists') {
                echo "<p style='color: red;'>Staff ID already exists. Please use a different ID.</p>";
            } elseif (isset($_GET['success']) && $_GET['success'] == 'registered') {
                echo "<p style='color: green;'>Registration successful. You can now <a href='loginPage.php'>log in</a>.</p>";
            }
            ?>
            <form action="handle_register.php" method="post">
                <div class="input-box">
                    <input type="text" name="staff_id" placeholder="Staff ID (Enter digits only)" required>
                </div>
                <div class="input-box">
                    <input type="text" name="staff_name" placeholder="Staff Name" required>
                </div>
                <div class="input-box">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit" class="btn">Register</button>
                <div class="login-link">
                    <p>Already have an account? <a href="loginPage.php">Log in</a></p>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
