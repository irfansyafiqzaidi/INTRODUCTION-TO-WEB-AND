<?php
session_start();
if (isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>About Us</title>
	<link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<section class="sub-header">
	<nav>
		<a href="index.php"><img src="images/logo.jpg"></a>
		<div class="nav-links">
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php">ABOUT</a></li>
				<li><a href="displaymenu.php">MENU</a></li>
				<li><a href="loginPage.php">STAFF PAGE</a></li>
			</ul>
	</nav>
	<h1>About Us</h1>
</section>

<!-----about us section---->

<section class="about-us">

	<div class="row">
		<div class="about-col">
			<h1>We serve the best burger in the town</h1>
			<p>Welcome to Beria Maju Enterprise Burger, where every bite is a celebration of flavor and quality. At Beria Maju Burger, we are passionate about creating the ultimate burger experience. Our journey began with a simple love for burgers and a vision to craft the perfect bite, blending the freshest ingredients with innovative recipes and exceptional service.<br><br>Founded in 2023, Beria Maju Enterprise Burger started as a small restaurant in the heart of downtown. Our founders, shared a dream of bringing gourmet burgers to their community. With dedication, hard work, and a commitment to excellence, Beria Maju Eneterprise Burger quickly grew into a beloved local eatery, known for its mouth-watering burgers and inviting atmosphere.</p>
		</div>
		<div class="about-col">
			<img src="images/shop.jpg">
		</div>
		
	</div>
	
</section>

<!-----footer-------->

<section class="footer">
	<h4>About us</h4>
	<p>Beria Maju Enterprise Burger is a restaurant that specializes in supplying the finest western food especially burgers.</p>
</section>

</body>
</html>