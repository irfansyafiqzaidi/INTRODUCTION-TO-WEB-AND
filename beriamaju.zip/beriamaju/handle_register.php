<?php
session_start();
include('dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $staffId = $_POST['staff_id'];
    $staffName = $_POST['staff_name'];
    $password = $_POST['password'];

    // Check if the staff ID already exists
    $checkQuery = "SELECT * FROM staff WHERE staff_id = '$staffId'";
    $checkResult = $dbc->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Staff ID already exists
        header("Location: registerPage.php?error=exists");
        exit();
    } else {
        // Insert new staff member
        $insertQuery = "INSERT INTO staff (staff_id, staff_password, staff_name) VALUES ('$staffId', '$password', '$staffName')";
        if ($dbc->query($insertQuery) === TRUE) {
            // Registration successful
            header("Location: registerPage.php?success=registered");
            exit();
        } else {
            echo "Error: " . $insertQuery . "<br>" . $dbc->error;
        }
    }
} else {
    // Redirect to registration page if the request method is not POST
    header("Location: registerPage.php");
    exit();
}
?>
