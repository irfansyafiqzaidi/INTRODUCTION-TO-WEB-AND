<?php
session_start();
include 'dbc.php'; // Ensure this file contains the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_index = $_POST['item_index'];
    $item_id = $_POST['item_id'];

    // Remove the item from the session cart
    if (isset($_SESSION['cart'][$item_index])) {
        unset($_SESSION['cart'][$item_index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex the array
    }

    // Delete the item from the database
    $query = "DELETE FROM cart WHERE food_id = ?";
    $stmt = $dbc->prepare($query);
    $stmt->bind_param('s', $item_id);
    $stmt->execute();
    $stmt->close();

    // Redirect back to the cart page
    header('Location: cart.php');
    exit();
}
?>
