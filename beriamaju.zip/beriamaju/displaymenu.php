<?php
session_start();
if (isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}
include "dbc.php"; // Include your database connection file

// Fetch menu items from the database
$query = "SELECT * FROM `food`";
$result = mysqli_query($dbc, $query);
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Menu</title>
	<link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<section class="sub-header4">
	<nav>
		<a href="index.php"><img src="images/logo.jpg"></a>
		<div class="nav-links">
			<ul>
				<li><a href="index.php">HOME</a></li>
				<li><a href="about.php">ABOUT</a></li>
				<li><a href="displaymenu.php">MENU</a></li>
				<li><a href="loginPage.php">STAFF PAGE</a></li>
			</ul>
		</div>
	</nav>
	<h1>Our Menu</h1>

</section>

<!-----menu display section---->

<section class="menu-display">

<div class="container">
		<h2>Menu:</h2>
		<div class="menu-items">
			<?php
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<div class='menu-item'>";
					echo "<img src='" . $row['food_image'] . "' alt='" . $row['food_name'] . "'>";
					echo "<h3>" . $row['food_name'] . "</h3>";
					echo "<p>" . $row['food_desc'] . "</p>";
					echo "<p>Price: $" . number_format($row['food_price'], 2) . "</p>";
					echo "</form>";
					echo "</div>";
				}
			} 
			else 
			{
				echo "<p>No menu items found.</p>";
			}
			?>
		</div>
	</div>

</section>


<!-----footer-------->

<section class="footer">
	<h4>About us</h4>
	<p>Beria Maju Enterprise Burger is a restaurant that specializes in supplying the finest western food especially burgers.</p>
</section>

</body>
</html>