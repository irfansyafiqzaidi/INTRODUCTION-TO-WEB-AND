<?php
session_start();
include('db.php'); // Include your database connection

$item_id = $_POST['item_id'];
$quantity = $_POST['quantity'];

// Function to get item details from the database
function getItemFromDatabase($item_id) {
    global $conn; // Use the global connection variable
    $stmt = $conn->prepare("SELECT * FROM items WHERE id = ?");
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

$item = getItemFromDatabase($item_id);

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$found = false;
foreach ($_SESSION['cart'] as &$cart_item) {
    if ($cart_item['item_id'] == $item_id) {
        $cart_item['quantity'] += $quantity;
        $cart_item['total'] = $cart_item['quantity'] * $cart_item['price'];
        $found = true;
        break;
    }
}

if (!$found) {
    $new_item = array(
        'item_id' => $item_id,
        'name' => $item['name'],
        'price' => $item['price'],
        'quantity' => $quantity,
        'total' => $quantity * $item['price']
    );
    $_SESSION['cart'][] = $new_item;
}

header('Location: cart.php');
exit;
?>
