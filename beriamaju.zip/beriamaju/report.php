<?php
session_start();
include('dbconnect.php');

// Fetch total sales and total orders
$total_sales_sql = "
SELECT 
    SUM(food.food_price * orders_food.food_quantity) as total_sales, 
    COUNT(DISTINCT orders_food.order_id) as total_orders
FROM 
    orders_food
JOIN 
    food ON orders_food.food_id = food.food_id
";
$total_sales_result = $dbc->query($total_sales_sql);
if ($total_sales_result === FALSE) {
    die("Error in total sales query: " . $dbc->error);
}
$total_sales_data = $total_sales_result->fetch_assoc();

// Fetch top-selling products
$top_selling_sql = "
SELECT 
    food.food_name, 
    SUM(orders_food.food_quantity) as total_quantity_sold
FROM 
    orders_food
JOIN 
    food ON orders_food.food_id = food.food_id
GROUP BY 
    orders_food.food_id
ORDER BY 
    total_quantity_sold DESC
LIMIT 5
";
$top_selling_result = $dbc->query($top_selling_sql);
if ($top_selling_result === FALSE) {
    die("Error in top selling query: " . $dbc->error);
}

$dbc->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Report</title>
    <link rel="stylesheet" href="reportStyle.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">
</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.jpg" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
            </ul>
        </nav>
        <div class="dropdown">
            <button class="dropbtn"><i class="fas fa-bars"></i></button>
            <div class="dropdown-content">
                <a href="#">Report</a>
                <a href="SchedulePage.php">Schedule</a>
                <a href="CustOrder.php">Order</a>
                <a href="logout.php">Log out</a>
            </div>
        </div>
    </header>

    <main>
        <h1>Admin Report</h1>
        <div class="summary">
            <div class="summary-item">
                <h2>Total Sales</h2>
                <p>RM<?php echo number_format($total_sales_data['total_sales'], 2); ?></p>
            </div>
            <div class="summary-item">
                <h2>Total Orders</h2>
                <p><?php echo $total_sales_data['total_orders']; ?></p>
            </div>
        </div>
        <h2>Report Summary</h2>
        <h3>Top Selling Food</h3>
        <table>
            <tr>
                <th>Food Name</th>
                <th>Quantity Sold</th>
            </tr>
            <?php
            if ($top_selling_result->num_rows > 0) {
                while ($row = $top_selling_result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row["food_name"]) . '</td>';
                    echo '<td>' . htmlspecialchars($row["total_quantity_sold"]) . '</td>';
                    echo '</tr>';
                }
            } else {
                echo "<tr><td colspan='2'>No results found</td></tr>";
            }
            ?>
        </table>
    </main>

    <div class="side-menu">
        <!-- Side menu content here -->
    </div>
</body>
</html>
