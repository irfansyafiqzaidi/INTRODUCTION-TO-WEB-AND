<?php
session_start();
require 'dbc.php'; // Database connection

// Fetch all food items
$query = "SELECT * FROM food";
$result = $dbc->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Beria Maju Enterprise - Menu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<section class="menu-display">
    <div class="container">
        <h2>Menu</h2>
        <div class="menu-items">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="menu-item">
                    <h3><?php echo htmlspecialchars($row['food_name']); ?></h3>
                    <p><?php echo htmlspecialchars($row['food_desc']); ?></p>
                    <p>Price: $<?php echo number_format($row['food_price'], 2); ?></p>
                    <form action="add_to_cart2.php" method="post">
                        <input type="hidden" name="food_id" value="<?php echo $row['food_id']; ?>">
                        <input type="number" name="quantity" value="1" min="1">
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>
            <?php } ?>
        </div>
    </div>
</section>
</body>
</html>
