<?php
session_start();
include('dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $staffId = $_POST['staff_id'];
    $password = $_POST['password'];

    $query = "SELECT * FROM staff WHERE staff_id = '$staffId' AND staff_password = '$password'";
    $result = $dbc->query($query);

    if ($result->num_rows > 0) {
        // Successful login
        $row = $result->fetch_assoc();
        $_SESSION['staff_id'] = $row['staff_id'];
        $_SESSION['staff_name'] = $row['staff_name'];
        header("Location: SchedulePage.php");
        exit();
    } else {
        // Invalid login
        header("Location: loginPage.php?error=invalid");
        exit();
    }
} else {
    // Redirect to login page if the request method is not POST
    header("Location: loginPage.php");
    exit();
}
?>
