<?php
session_start();
include('dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $staffId = $_SESSION['staff_id'];
    $day = $_POST['fstaffday'];
    $startTime = $_POST['fstaffstarttime'];
    $endTime = $_POST['fstaffendtime'];

    // Check if the entry exists
    $checkQuery = "SELECT * FROM shift WHERE staff_id = '$staffId' AND day = '$day'";
    $checkResult = $dbc->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Update the existing entry
        $updateQuery = "UPDATE shift SET start_time = '$startTime', end_time = '$endTime' WHERE staff_id = '$staffId' AND day = '$day'";
        $dbc->query($updateQuery);
    } else {
        // Insert a new entry
        $insertQuery = "INSERT INTO shift (staff_id, day, start_time, end_time) VALUES ('$staffId', '$day', '$startTime', '$endTime')";
        $dbc->query($insertQuery);
    }

    // Redirect back to the schedule page
    header("Location: SchedulePage.php?status=success");
    exit();
} else {
    // Redirect back to the schedule page if the request method is not POST
    header("Location: SchedulePage.php");
    exit();
}
?>
