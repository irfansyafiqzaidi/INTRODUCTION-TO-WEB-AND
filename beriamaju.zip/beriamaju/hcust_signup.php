<?php
session_start();
include('dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $custIc = $_POST['cust_ic'];
    $custName = $_POST['cust_name'];
    $custPhone = $_POST['cust_phone'];
    $cpassword = $_POST['cust_password'];

    // Check if the staff ID already exists
    $checkQuery = "SELECT * FROM customer WHERE customer_ic = '$custIc'";
    $checkResult = $dbc->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Staff ID already exists
        header("Location: cust_signup.php?error=exists");
        exit();
    } else {
        // Insert new staff member
        $insertQuery = "INSERT INTO customer (customer_ic, customer_name, customer_phonenum, customer_password) VALUES ('$custIc', '$custName', '$custPhone','$cpassword')";
        if ($dbc->query($insertQuery) === TRUE) {
            // Registration successful
            header("Location: cust_signup.php?success=registered");
            exit();
        } else {
            echo "Error: " . $insertQuery . "<br>" . $dbc->error;
        }
    }
} else {
    // Redirect to registration page if the request method is not POST
    header("Location: cust_signup.php");
    exit();
}
?>