<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beria Maju Enterprise - Payment</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
<section class="sub-header3">
    <nav>
        <a href="index.php"><img src="images/logo.jpg"></a>
        <div class="nav-links">
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
                <li><a href="displaymenu.php">MENU</a></li>
            </ul>
        </div>
    </nav>

</section>


<section class="payment-display">
    <div class="container">
        <h2>Payment Information</h2>
        <form class="payment-form" method="POST" action="receipt.php">
            <label for="name">Name on Card:</label>
            <input type="text" id="name" name="name" required>
            <label for="cardnumber">Card Number:</label>
            <input type="text" id="cardnumber" name="cardnumber" required>
            <label for="expiry">Expiry Date:</label>
            <input type="text" id="expiry" name="expiry" required>
            <label for="cvv">CVV:</label>
            <input type="text" id="cvv" name="cvv" required>
            <input type="submit" value="Pay Now">
        </form>
    </div>
</section>
</body>
</html>